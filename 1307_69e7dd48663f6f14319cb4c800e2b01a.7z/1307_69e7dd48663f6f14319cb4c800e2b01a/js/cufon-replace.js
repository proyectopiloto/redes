Cufon.replace('h1, h2', { fontFamily: 'Avenir', hover:true });

